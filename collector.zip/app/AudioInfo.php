<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AudioInfo extends Model
{
    //Table name
    public $table = 'audio_info';
    public $timestamps = false;
}
