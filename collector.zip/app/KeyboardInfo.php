<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class KeyboardInfo extends Model
{
    //Table name
    public $table = 'keyboard_info';
    public $timestamps = false;
}
