@extends('layouts.app')

@section('content')
<h1> this is about </h1>
@endsection