@extends('layouts.app')

@section('content')
<h1> this is services </h1>
@endsection