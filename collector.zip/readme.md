# Collector

A web app developed as a part of my bachelor's thesis. Note: the development is still in progress! The app will be updated regularly.

The app is available at:
http://collector-env-1.2ta8wpyecx.us-east-2.elasticbeanstalk.com.

Collector shows the collected data from Android mobile phones:
- location
- keyboard input
- audio

The data can be filtered by user name. More options will be added in the future.

For the implementation of the mobile app, check:
https://github.com/mirnabaksa/ZavRad
