<footer>
<div class="container">
    <span class="text-muted">Author: Mirna Baksa, 2018.</span>
</div>
</footer>