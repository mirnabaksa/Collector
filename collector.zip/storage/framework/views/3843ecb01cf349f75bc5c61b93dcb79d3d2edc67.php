<?php $__env->startSection('title'); ?>
Collected location info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
Location info collected from Android phone sensors.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headers'); ?>
<th>#</th>
<th>Latitude</th>
<th>Longitude</th>
<th>Date</th>
<th>Address</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?> 
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
        <th><?php echo e($l->id); ?> </th>
        <th><?php echo e($l->latitude); ?> </th>
        <th><?php echo e($l->longitude); ?> </th>
        <th><?php echo e($l->datetime); ?> </th>
        <th><?php echo e($l->address); ?> </th>
</tr> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('data.datalayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>