<?php $__env->startSection('content'); ?>
    <?php if(count($data) > 0): ?>
    <section class="jumbotron text-center">
            <div class="container">
              <h1 class="jumbotron-heading"><?php echo $__env->yieldContent('title'); ?></h1>
              <p class="lead text-muted"><?php echo $__env->yieldContent('description'); ?></p>
            </div>
    </section>
          
          <div class ="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <?php echo $__env->yieldContent('headers'); ?>
                        </tr>
                     </thead>
                     
                     <?php echo $__env->yieldContent('info', $data); ?>
             </div>
    <?php else: ?>
    <section class="jumbotron text-center">
            <div class="container">
              <h1 class="jumbotron-heading">No info collected yet!</h1>
            </div>
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>